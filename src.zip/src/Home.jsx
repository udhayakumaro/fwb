import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Import axios
import { BsCircleFill, BsFillCheckCircleFill, BsFillTrashFill } from 'react-icons/bs'; // Assuming you've imported these icons
import Create from './Create';
import './App.css';

function Home() {
    const [todos, setTodos] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3001/get')
            .then(result => setTodos(result.data))
            .catch(err => console.log(err));
    }, []);

    const handleEdit = (id) => { // Pass id as parameter
        axios.put('http://localhost:3001/update/' + id)
            .then(result => {
                window.location.reload(); // Use window.location.reload() instead of location.reload()
            })
            .catch(err => console.log(err));
    };

    const handleDelete = (id) => { // Pass id as parameter
        axios.delete('http://localhost:3001/delete/' + id)
            .then(result => {
                window.location.reload(); // Use window.location.reload() instead of location.reload()
            })
            .catch(err => console.log(err));
    };

    return (
        <div className='home'>
            <h2>TO DO LIST</h2>
            <Create />
            <br />
            {
                todos.length > 0 // Check if todos is not empty before mapping
                    ? todos.map(todo => (
                        <div className='task' key={todo._id}>
                            <div className='checkbox' onClick={() => handleEdit(todo._id)}> {/* Corrected onClick */}
                                {todo.done ? <BsFillCheckCircleFill /> : <BsCircleFill className='icon' />}
                                <p className={todo.done ? "line_through" : ""}>{todo.task}</p>
                            </div>
                            <div>
                                <span><BsFillTrashFill className='icon' onClick={() => handleDelete(todo._id)} /></span> {/* Corrected onClick */}
                            </div>
                        </div>
                    ))
                    : <p>No todos found</p>
            }
        </div>
    );
}

export default Home;
