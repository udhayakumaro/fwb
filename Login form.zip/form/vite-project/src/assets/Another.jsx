import React from 'react';

const AnotherPage = () => {
  return (
    <div>
      <h1>Another Page</h1>
      <p>This is another page after successful login.</p>
    </div>
  );
};

export default AnotherPage;
